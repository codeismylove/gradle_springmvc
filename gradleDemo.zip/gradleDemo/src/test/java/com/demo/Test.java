/**
 * 
 */
package com.demo;

/**
 * @author linzhenying
 * @date 2016��10��21��
 */
public class Test {
	public static void main(String arg[]){
		System.out.print("test");
		System.out.println("is this good");
	}	
}
